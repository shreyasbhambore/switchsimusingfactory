// SimProject.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include "..\FactoryDLL\Factory.h"
#include "..\BaseDLL\Base.h"


using namespace std;

int main()
{
	Factory *f=new Factory();
	Base *b = f->getSim();
	b->check();
    return 0;
}

