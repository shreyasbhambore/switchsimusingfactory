#pragma once

#ifdef BASEDLL_EXPORTS
# define EXIM __declspec(dllexport)
#else
#define EXIM __declspec(dllimport)
#endif
class EXIM Base
{
public:
	Base();
	~Base();
	virtual void check() = 0;
};

