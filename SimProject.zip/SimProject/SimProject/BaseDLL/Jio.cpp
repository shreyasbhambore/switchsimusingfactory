#include "stdafx.h"
#include "Jio.h"

#include <iostream>
using namespace std;
Jio::Jio()
{
}


Jio::~Jio()
{
}


void Jio::check()
{
	cout << "Jio" << endl;
}