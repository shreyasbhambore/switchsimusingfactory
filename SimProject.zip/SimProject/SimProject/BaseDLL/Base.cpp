#include "stdafx.h"
#include "Base.h"
#include <iostream>
using namespace std;

Base::Base()
{
}


Base::~Base()
{
}
