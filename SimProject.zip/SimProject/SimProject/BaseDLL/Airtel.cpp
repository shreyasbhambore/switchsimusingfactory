#include "stdafx.h"
#include "Airtel.h"
#include <iostream>
using namespace std;

Airtel::Airtel()
{
}


Airtel::~Airtel()
{
}


void Airtel::check()
{
	cout << "Airtel" << endl;
}