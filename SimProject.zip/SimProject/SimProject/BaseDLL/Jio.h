#pragma once
#include "Base.h"
#ifdef BASEDLL_EXPORTS
# define EXIM __declspec(dllexport)
#else
#define EXIM __declspec(dllimport)
#endif
class EXIM Jio:public Base
{
public:
	Jio();
	~Jio();
	void check();
};

