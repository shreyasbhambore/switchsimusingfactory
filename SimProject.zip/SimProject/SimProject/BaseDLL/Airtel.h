#pragma once
#ifdef BASEDLL_EXPORTS
# define EXIM __declspec(dllexport)
#else
#define EXIM __declspec(dllimport)
#endif
#include "Base.h"
class EXIM Airtel:public Base
{
public:
	Airtel();
	~Airtel();
	void check();
};

