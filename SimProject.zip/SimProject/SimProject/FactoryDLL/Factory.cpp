#include "stdafx.h"
#include "Factory.h"

#include "Jio.h"
#include "Airtel.h"
#include <iostream>
using namespace std;
Factory::Factory()
{
}


Factory::~Factory()
{
}

Base * Factory::getSim()
{
	int k;
	cout << "1 or 2" << endl;
	cin >> k;
	switch (k) 
	{
	case 1:return new Airtel();
		break;
	case 2:return new Jio();
		break;
	default:
		return NULL;
	
	
	}
	
}