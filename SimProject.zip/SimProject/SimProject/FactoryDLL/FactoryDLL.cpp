// FactoryDLL.cpp : Defines the exported functions for the DLL application.
//

#include "stdafx.h"


