#pragma once
#include "..\BaseDLL\Base.h"


#ifdef FACTORYDLL_EXPORTS
# define FACTORYDLL __declspec(dllexport)
#else
#define FACTORYDLL __declspec(dllimport)
#endif
class FACTORYDLL Factory
{
	Base *b;
public:
	Factory();
	~Factory();
	Base* getSim();
};

